-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: mariadb
-- Gegenereerd op: 31 okt 2023 om 13:37
-- Serverversie: 11.1.2-MariaDB-1:11.1.2+maria~ubu2204
-- PHP-versie: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Bo_Nvvn`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sdg`
--

CREATE TABLE `sdg` (
  `Id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `color` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `sdg`
--

INSERT INTO `sdg` (`Id`, `title`, `img`, `content`, `color`) VALUES
(1, 'SDG 1 Geen armoede', 'img/sdg1.svg', 'Einde aan de armoede gaat over het verminderen van alle vormen van armoede. De SDG-agenda vraagt speciale aandacht voor sociale bescherming, gelijke economische rechten en weerbaarheid van arme en kwetsbare groepen. Omdat armoede in Nederland er anders uit ziet dan armoede in de armste landen van de wereld is dit voor Nederland aangepast. Nederland richt zich op het voorkomen en tegengaan van armoede en problematische schulden, met speciale aandacht voor kinderen die in armoede leven.', '#EB3323'),
(2, 'SDG 2 Geen honger', 'img/sdg2.svg', 'Einde aan de honger gaat over het doel honger te beëindigen, voedselzekerheid te garanderen en betere voeding en duurzame landbouw te stimuleren. Omdat in Nederland ondervoeding en voedselonzekerheid niet vaak voorkomen, kijken we ook wel naar obesitas, overvoeding en hoe wij voedsel produceren: hoe duurzaam doen we dat? En welk impact heeft dat op de leefomgeving. Ook voedselverspilling tegengaan hoort hierbij.', '#E4AC3E'),
(3, 'SDG 3. Goede gezondheid en welzijn', 'img/sdg3.svg', 'Goede gezondheid en welzijn gaat over dat iedereen de kans heeft in zo goed mogelijke gezondheid te leven, door behandeling van ziektes en psychische problemen en voorkomen dat mensen te vroeg sterven. Dit doel gaat ook over het tegengaan van verslaving ( alcohol, drugs, roken) en ook over het voorkomen van verkeersdoden.', '#479d2c'),
(4, 'SDG 4. Kwaliteitsonderwijs\r\n', 'img/sdg4.svg', 'Kwaliteitsonderwijs gaat over dat iedereen toegang heeft tot goed onderwijs. Passende en scholing is voor alle leeftijdsgroepen en in alle levensfasen van belang, van kleuter- en basisonderwijs tot beroeps- en hoger onderwijs, en daarna via ‘leven lang ontwikkelen’. Vaardigheden van leerlingen worden voor een groot deel bepaald door de kwaliteit van het aangeboden onderwijs. Bovendien zorgt onderwijs ervoor dat de bevolking nu en in de toekomst over de goede vaardigheden beschikt om te functioneren in een kennismaatschappij en goed kunnen meedraaien in de maatschappij.\r\n', '#c82c2d'),
(5, 'SDG 5. Gendergelijkheid', 'img/sdg5.svg', 'Mannen en vrouwen moeten gelijk behandeld worden en een gelijkwaardige plek in de samenleving hebben. Hiervoor moet een eind komen aan achterstand van vooral vrouwen en meisjes op allerlei gebieden, waaronder dwang en geweld, werk en zorg, maar ook invloed in het openbare leven.', '#EC5128'),
(6, 'SDG 6. Schoon water en sanitair', 'img/sdg6.svg', 'De toegang tot drinkwater en sanitair en duurzaam beheer van water vormen de kern van SDG 6. Vrijwel iedereen in Nederland heeft toegang tot schoon drinkwater en goed sanitair. Drinkwater moet betaalbaar blijven voor ons allemaal. De vraag naar drinkwater is tijdens de afgelopen droge en hete zomers gestegen. Ook de groeiende bevolking en de behoefte aan meer woningen, en daarmee meer aansluitingen, zorgen voor meer vraag. Omdat er weinig mogelijkheden zijn om meer water te winnen, concurreren drinkwaterbedrijven steeds vaker met de belangen van natuur, landbouw en klimaatactie. Als er vaker droge zomers vaker voorkomen, kan de leveringszekerheid van drinkwater op termijn onder druk komen.', '#65ABD1'),
(7, 'SDG 7. Betaalbare en duurzame energie', 'img/sdg7.svg', 'Energiezekerheid, verduurzaming en energie-efficiëntie zijn erg belangrijk. Steeds minder mensen hebben de mogelijkheid om voldoende energie te gebruiken omdat het heel duur is geworden. In koude winters gebruiken veel mensen daarom extra dikke kleding en dekens om lekker warm te blijven en de kachel een beetje kouder te zetten.', '#ECC05A'),
(8, 'SDG 8. Eerlijk werk en economische groei', 'img/sdg8.svg', 'Economische groei, met aandacht voor innovatie, ondernemerschap en milieu is erg belangrijk voor een duurzame wereld. Economische activiteiten kunnen op lange termijn schadelijk zijn voor de brede welvaart, de leefomgeving en het welbevinden van de mensen en dieren. Voor de productie van goederen en diensten is input nodig van kapitaal, arbeid en grondstoffen. Worden deze duurzaam en productief ingezet? En hoe worden de winsten en inkomens verdeeld worden over burgers en bedrijven?', '#862A35'),
(9, 'SDG 9. Industrie, innovatie en infrastructuur\r\n', 'img/sdg9.svg', 'Infrastructuur en mobiliteit, industrie en duurzame bedrijvigheid, en kennis en innovatie zijn belangrijk in een duurzame wereld. Een toegankelijke infrastructuur en mobiliteit voor iedereen. Mobiliteit en infrastructuur helpen mensen om van plek a naar plek b te komen, bijvoorbeeld naar het werk, contacten te onderhouden en vrije tijd in te vullen met sport, muziek of theater. Als mensen lang in de file staan dan is dat nadelig voor het milieu en wanneer mensen te hard rijden dan gaat het niet goed met de verkeersveiligheid en het milieu.', '#DF7845'),
(10, 'SDG 10. Ongelijkheid verminderen', 'img/sdg10.svg', 'Sociale samenhang is onmisbaar voor het goed functioneren van een samenleving. De sociale infrastructuur – familie, buren, vrienden, verenigingen en hulp en ondersteuning – vormt hiervan de basis. Mensen moeten mee kunnen doen, zodat ze zich deel van een groep kunnen voelen. Dat geld ook voor mensen uit andere landen die hier komen werken.', '#D84670'),
(11, 'SDG 11. Duurzame steden en gemeenschappen', 'img/sdg11.svg', 'Er zijn weinig betaalbare woningen beschikbaar, hoe houden we de lokale leefomgeving veilig, betaalbaar, toegankelijk en duurzaam? Hoeveel ruimte is er per persoon beschikbaar en hoe gaat het met de afvalverwerking en overheidsuitgaven voor het milieu. Een schone en veilige leefomgeving in het dorp, de wijk of de stad is daarbij erg belangrijk.', '#E6B355'),
(12, 'SDG 12. Verantwoorde consumptie en productie', 'img/sdg12.svg', 'Bedrijven, overheid en consumenten worden aangespoord om bewuste keuzes te maken om de druk op het milieu te verlagen en de minder afhankelijk te zijn van grondstoffen. Zo beperken we de negatieve gevolgen van ons consumptie voor volgende generaties.', '#D68E46'),
(13, 'SDG 13. Klimaatactie', 'img/sdg13.svg', 'Door doelen te stellen voor weerbaarheid en klimaatadaptatie, nationaal klimaatbeleid, en middelen om bewustwording en draagvlak te creëren voor de klimaatmaatregelen. Met het Deltaprogramma, dat Nederland moet beschermen tegen overstromingen en de gevolgen van extreem weer, kunnen we belangrijke stappen maken. Ook de vermindering van uitstoot van broeikasgassen, waarbij energiebesparing en hernieuwbare energie spelen een belangrijke rol.', '#608D42'),
(14, 'SDG 14. Leven in het water', 'img/sdg14.svg', 'Zeewater bedekt ongeveer driekwart van de planeet en vormt het grootste ecosysteem ter wereld. De toenemende negatieve effecten van klimaatverandering, overbevissing en vervuiling vormen een bedreiging voor de waarde van het ecosysteem zelf en voor het gebruik dat ervan gemaakt wordt. Aandacht voor de waterkwaliteit en de duurzaamheid van de visserij in de Noordzee zijn voor ons erg belangrijk.', '#4981D2'),
(15, 'SDG 15. Leven op het land', 'img/sdg15.svg', 'Bescherming en herstel van ecosystemen en biodiversiteit versterken de weerbaarheid tegen toenemende bevolkingsdruk, intensivering van landgebruik en klimaatverandering. Gezonde ecosystemen zijn erg belangrijk zoals de beschikbaarheid van schoon water en schone lucht, de aanwezigheid van insecten voor bestuiving en de mogelijkheden voor ontspanning, recreatie en educatie.', '#87C05F'),
(16, 'SDG 16. Vrede, justitie en sterke publieke diensten', 'img/sdg16.svg', 'Voor veiligheid en vrede moeten alle vormen van geweld en de sterfte die daarvan het gevolg is verminderd worden. Speciale aandacht gaat uit naar geweld tegen kinderen en naar georganiseerde misdaad. In een veilige samenleving heeft iedereen toegang tot het rechtssysteem, en wordt corruptie tegengegaan. Het ervaren van onveiligheid, met gevoelens van kwetsbaarheid en onzekerheid kunnen een grote impact hebben op het persoonlijke leven.', '#305592'),
(17, 'SDG 17. Partnerschap om doelstelling te bereiken', 'img/sdg17.svg', 'Dit vraagt om samenhangend beleid, een meewerkende omgeving en de bereidheid tot aangaan van nieuwe partnerschappen. Met wie werk je samen en waarom? Het gaat er bij dit doel om welk effect ontwikkelingen in Nederland op andere landen hebben.', '#2F2C8B');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `sdg`
--
ALTER TABLE `sdg`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `sdg`
--
ALTER TABLE `sdg`
  MODIFY `Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
